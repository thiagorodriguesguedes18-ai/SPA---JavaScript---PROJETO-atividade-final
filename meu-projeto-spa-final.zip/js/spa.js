const rotas = {
  home: `
    <h2>Bem-vindo!</h2>
    <p>Esta é a página inicial da sua aplicação SPA acessível.</p>
  `,
  sobre: `
    <h2>Sobre</h2>
    <p>Aplicação em JavaScript puro demonstrando manipulação do DOM, SPA, validação e acessibilidade.</p>
  `,
  contato: `
    <h2>Contato</h2>
    <form id="form-contato" novalidate>
      <div>
        <label for="nome">Nome</label>
        <input type="text" id="nome" name="nome" required aria-required="true" />
      </div>
      <div>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required aria-required="true" />
      </div>
      <div>
        <label for="mensagem">Mensagem</label>
        <textarea id="mensagem-text" name="mensagem" rows="4"></textarea>
      </div>
      <button type="submit">Enviar</button>
    </form>
    <div id="mensagem" class="message" role="status" aria-live="polite"></div>
  `
};

function setContent(html){
  const conteudo = document.getElementById("conteudo");
  conteudo.innerHTML = html;
  // move focus to main content for accessibility
  document.getElementById("main").focus();
}

function navegar(){
  const hash = location.hash.substring(1) || "home";
  setContent(rotas[hash] || rotas.home);
  if(hash === "contato"){
    iniciarValidacao();
  }
  highlightActiveLink(hash);
}

function highlightActiveLink(route){
  document.querySelectorAll(".menu a").forEach(a=>{
    a.classList.toggle("active", a.getAttribute("data-route") === route);
  });
}

window.addEventListener("hashchange", navegar);
window.addEventListener("load", ()=>{
  // enable keyboard navigation on menu links
  document.querySelectorAll(".menu a").forEach(a=>{
    a.addEventListener("keydown", (e)=>{
      if(e.key === "Enter" || e.key === " "){
        e.preventDefault();
        a.click();
      }
    });
  });
  navegar();
});
