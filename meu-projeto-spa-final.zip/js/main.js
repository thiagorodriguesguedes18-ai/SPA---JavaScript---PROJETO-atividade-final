document.addEventListener("DOMContentLoaded", ()=>{
  const toggle = document.getElementById("contrastToggle");
  toggle.addEventListener("click", ()=>{
    const pressed = toggle.getAttribute("aria-pressed") === "true";
    toggle.setAttribute("aria-pressed", String(!pressed));
    document.documentElement.classList.toggle("high-contrast");
  });

  // Improve skip-link behaviour: focus main when used
  const skip = document.querySelector(".skip-link");
  skip.addEventListener("click", (e)=>{
    const main = document.getElementById("main");
    setTimeout(()=> main.focus(), 40);
  });
});
