function iniciarValidacao(){
  const form = document.getElementById("form-contato");
  if(!form) return;
  const mensagem = document.getElementById("mensagem");
  form.addEventListener("submit", function(e){
    e.preventDefault();
    const nomeEl = document.getElementById("nome");
    const emailEl = document.getElementById("email");
    const nome = nomeEl.value.trim();
    const email = emailEl.value.trim();
    mensagem.innerHTML = "";
    nomeEl.removeAttribute("aria-invalid");
    emailEl.removeAttribute("aria-invalid");

    if(nome === "" || email === ""){
      if(nome === "") nomeEl.setAttribute("aria-invalid", "true");
      if(email === "") emailEl.setAttribute("aria-invalid", "true");
      mensagem.innerHTML = '<p style="color:red;">Por favor preencha todos os campos obrigatórios.</p>';
      mensagem.focus();
      return;
    }

    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if(!emailRe.test(email)){
      emailEl.setAttribute("aria-invalid", "true");
      mensagem.innerHTML = '<p style="color:red;">Digite um endereço de e-mail válido.</p>';
      mensagem.focus();
      return;
    }

    mensagem.innerHTML = '<p style="color:green;">Mensagem enviada com sucesso!</p>';
    form.reset();
  });
}
